import './Components/Compo.css';
import AllRoute from './Components/AllRoute';

function App() {
  return (
    <div className="App">
      <AllRoute/>
    </div>
  );
}

export default App;
