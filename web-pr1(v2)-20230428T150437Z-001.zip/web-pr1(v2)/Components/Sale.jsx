import React from 'react'
import Header from './Header'

function Sale() {
  return (
    <div>
        <Header/>
      sale not available
    </div>
  )
}

export default Sale
