import React from 'react'
import Header from './Header'

function Collection() {
  return (
    <div>
        <Header/>
      collection will declare soon
    </div>
  )
}

export default Collection
